

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Dashboard</h1>
            <p class="page-subtitle">Welcome back, <?php echo e(Auth::user()->name); ?>! Here's what's happening today.</p>
        </div>
        <div class="page-actions">
            <a href="<?php echo e(route('admin.activate-subscriber')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-lg me-2"></i>Activate Subscriber
            </a>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4 mb-4">
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-card-icon bg-primary-soft">
                    <i class="bi bi-people text-primary"></i>
                </div>
                <div class="stat-card-content">
                    <span class="stat-label">Total Subscribers</span>
                    <h3 class="stat-value"><?php echo e(number_format($totalSubscribers)); ?></h3>
                    <span class="stat-change positive">
                        <i class="bi bi-database"></i> All time
                    </span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-card-icon bg-success-soft">
                    <i class="bi bi-calendar-check text-success"></i>
                </div>
                <div class="stat-card-content">
                    <span class="stat-label">Today's Activations</span>
                    <h3 class="stat-value"><?php echo e(number_format($todaySubscribers)); ?></h3>
                    <span class="stat-change positive">
                        <i class="bi bi-clock"></i> Today
                    </span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-card-icon bg-warning-soft">
                    <i class="bi bi-calendar-week text-warning"></i>
                </div>
                <div class="stat-card-content">
                    <span class="stat-label">This Week</span>
                    <h3 class="stat-value"><?php echo e(number_format($weekSubscribers)); ?></h3>
                    <span class="stat-change positive">
                        <i class="bi bi-calendar"></i> Week
                    </span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-card-icon bg-info-soft">
                    <i class="bi bi-calendar-month text-info"></i>
                </div>
                <div class="stat-card-content">
                    <span class="stat-label">This Month</span>
                    <h3 class="stat-value"><?php echo e(number_format($monthSubscribers)); ?></h3>
                    <span class="stat-change positive">
                        <i class="bi bi-calendar-range"></i> <?php echo e(now()->format('F')); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Row -->
    <div class="row g-4 mb-4">
        <!-- Recent Subscribers -->
        <div class="col-12">
            <div class="content-card">
                <div class="card-header-custom">
                    <h5 class="card-title-custom">Recent Activations</h5>
                    <a href="<?php echo e(route('admin.activate-subscriber')); ?>" class="view-all">View All <i
                            class="bi bi-arrow-right"></i></a>
                </div>
                <div class="table-responsive">
                    <table class="table table-custom">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>SIM</th>
                                <th>MSISDN</th>
                                <th>Plan SOC</th>
                                <th>Label</th>
                                <th>Status</th>
                                <th>Created</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentSubscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><span class="order-id"><?php echo e(Str::limit($subscriber->sim, 15)); ?></span></td>
                                    <td><strong><?php echo e($subscriber->msisdn ?? 'N/A'); ?></strong></td>
                                    <td><?php echo e($subscriber->plan_soc); ?></td>
                                    <td><?php echo e($subscriber->label); ?></td>
                                    <td>
                                        <?php if($subscriber->api_status): ?>
                                            <span
                                                class="status-badge status-completed"><?php echo e($subscriber->api_status); ?></span>
                                        <?php else: ?>
                                            <span class="status-badge status-pending">Pending</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($subscriber->created_at->format('M d, Y H:i')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="bi bi-inbox display-6 d-block mb-2"></i>
                                            No subscribers found. <a
                                                href="<?php echo e(route('admin.activate-subscriber')); ?>">Activate your first
                                                subscriber</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jfmobile\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>